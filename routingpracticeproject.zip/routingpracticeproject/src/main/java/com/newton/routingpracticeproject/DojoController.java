package com.newton.routingpracticeproject;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DojoController {
	
	@RequestMapping("/{string}")
    public String dojo(@PathVariable("string") String string){
		String str = string;
		if(str.equals("dojo")) {
			return "The " + str + " is awesome!";
		}
		else if(str.equals("san-jose")) {
			return "SJ dojo is the headquarters";
		}
		else if(str.equals("burbank-dojo")) {
			return "Burbank Dojo is located in Southern California";
		}
		else {
			return "/" + str + " is not a valid URL";
		}
			
    }
	 
//	@RequestMapping("/{burbank}-{dojo}")
//    public String burbankdojo(@PathVariable("burbank") String burbank, @PathVariable("dojo") String dojo){
//		burbank = burbank.substring(0,1).toUpperCase() + burbank.substring(1).toLowerCase();
//		dojo = dojo.substring(0,1).toUpperCase() + dojo.substring(1).toLowerCase();
//		return String.format("%s %s is located in Southern California", burbank, dojo);
//    } 


}

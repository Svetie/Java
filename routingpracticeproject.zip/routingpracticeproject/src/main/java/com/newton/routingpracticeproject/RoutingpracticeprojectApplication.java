package com.newton.routingpracticeproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoutingpracticeprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoutingpracticeprojectApplication.class, args);
	}

}

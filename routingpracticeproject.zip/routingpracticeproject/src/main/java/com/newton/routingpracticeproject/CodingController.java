package com.newton.routingpracticeproject;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/coding")
public class CodingController {
	
    // GET request, text 'Hello Coding Dojo!'
    @RequestMapping(value="", method=RequestMethod.GET)
    public String hello(){
    	return "Hello Coding Dojo!";
    }
    
    // GET request, text 'Python/Django was awesome!'
    @RequestMapping(value="/python", method=RequestMethod.GET)
    public String pyhton(){
    	return "Python/Django was awesome!";
    }

    @RequestMapping(value="/java", method=RequestMethod.GET)
    public String java(){
    	return "Java/Spring is better!";
    }
	
}
